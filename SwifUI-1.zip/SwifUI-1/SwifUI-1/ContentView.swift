//
//  ContentView.swift
//  SwifUI-1
//
//  Created by Akash Soni on 29/08/19.
//  Copyright © 2019 Akash Soni. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            HStack{
                Text("Hello World")
                Text("Hello World")
                Text("Hello World")
                Text("Hello World")

            }.padding()
            VStack{
                Text("Hello World")
                Text("Hello World")
                Text("Hello World")
                Text("Hello World")
                Button(action: {
                  
                }) {
                  Text("Hit Me!")
                }
            }
        
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
